
document.addEventListener('DOMContentLoaded', () => {
    const stationsList = document.getElementById('stations-list');
    const addEditForm = document.getElementById('add-edit-station-form');
    const cancelEditButton = document.getElementById('cancel-edit');
    const messageBox = document.getElementById('message');

    // Base URL for API
    const API_BASE_URL = "http://localhost:5000/api/stations";

    // Fetch and display stations
    async function fetchStations() {
        try {
            const response = await fetch(API_BASE_URL);
            const stations = await response.json();
            stationsList.innerHTML = '';
            stations.forEach(station => {
                const listItem = document.createElement('li');
                listItem.innerHTML = `
                    <span>${station.name} - ${station.location}</span>
                    <div>
                        <button onclick="editStation(${station.id})">Edit</button>
                        <button onclick="deleteStation(${station.id})">Delete</button>
                    </div>
                `;
                stationsList.appendChild(listItem);
            });
        } catch (error) {
            console.error('Error fetching stations:', error);
        }
    }

    // Add or edit a station
    addEditForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const stationId = document.getElementById('station-id').value;
        const stationName = document.getElementById('station-name').value;
        const stationLocation = document.getElementById('station-location').value;

        const method = stationId ? 'PUT' : 'POST';
        const url = stationId ? `${API_BASE_URL}/${stationId}` : API_BASE_URL;

        try {
            const response = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: stationName, location: stationLocation })
            });

            if (response.ok) {
                messageBox.textContent = 'Station saved successfully!';
                addEditForm.reset();
                fetchStations();
            } else {
                messageBox.textContent = 'Error saving station.';
            }
        } catch (error) {
            console.error('Error saving station:', error);
        }
    });

    // Delete a station
    window.deleteStation = async (id) => {
        try {
            const response = await fetch(`${API_BASE_URL}/${id}`, { method: 'DELETE' });
            if (response.ok) {
                messageBox.textContent = 'Station deleted successfully!';
                fetchStations();
            } else {
                messageBox.textContent = 'Error deleting station.';
            }
        } catch (error) {
            console.error('Error deleting station:', error);
        }
    };

    // Edit a station
    window.editStation = (id) => {
        const station = stationsList.querySelector(`li[data-id='${id}']`);
        document.getElementById('station-id').value = id;
        document.getElementById('station-name').value = station.dataset.name;
        document.getElementById('station-location').value = station.dataset.location;
    };

    // Cancel editing
    cancelEditButton.addEventListener('click', () => {
        addEditForm.reset();
        messageBox.textContent = '';
    });

    // Initial fetch
    fetchStations();
});
