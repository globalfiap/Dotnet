
using EcoDriveLocator.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EcoDriveLocator.Infrastructure.Repositories
{
    public interface IChargingSessionRepository
    {
        Task<IEnumerable<ChargingSession>> GetAllChargingSessionsAsync();
        Task<ChargingSession> GetChargingSessionByIdAsync(int id);
        Task AddChargingSessionAsync(ChargingSession session);
        Task UpdateChargingSessionAsync(ChargingSession session);
        Task DeleteChargingSessionAsync(int id);
    }
}
