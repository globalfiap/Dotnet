
using EcoDriveLocator.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EcoDriveLocator.Infrastructure.Repositories
{
    public interface IStationRepository
    {
        Task<IEnumerable<Station>> GetAllStationsAsync();
        Task<Station> GetStationByIdAsync(int id);
        Task AddStationAsync(Station station);
        Task UpdateStationAsync(Station station);
        Task DeleteStationAsync(int id);
    }
}
