
using EcoDriveLocator.Core.Entities;
using EcoDriveLocator.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EcoDriveLocator.Infrastructure.Repositories
{
    public class ChargingSessionRepository : IChargingSessionRepository
    {
        private readonly ApplicationDbContext _context;

        public ChargingSessionRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<ChargingSession>> GetAllChargingSessionsAsync()
        {
            return await _context.ChargingSessions.Include(cs => cs.Station).ToListAsync();
        }

        public async Task<ChargingSession> GetChargingSessionByIdAsync(int id)
        {
            return await _context.ChargingSessions.Include(cs => cs.Station).FirstOrDefaultAsync(cs => cs.Id == id);
        }

        public async Task AddChargingSessionAsync(ChargingSession session)
        {
            await _context.ChargingSessions.AddAsync(session);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateChargingSessionAsync(ChargingSession session)
        {
            _context.ChargingSessions.Update(session);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteChargingSessionAsync(int id)
        {
            var session = await GetChargingSessionByIdAsync(id);
            if (session != null)
            {
                _context.ChargingSessions.Remove(session);
                await _context.SaveChangesAsync();
            }
        }
    }
}
