
using Microsoft.EntityFrameworkCore;
using EcoDriveLocator.Core.Entities;

namespace EcoDriveLocator.Infrastructure.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Station> Stations { get; set; }
        public DbSet<ChargingSession> ChargingSessions { get; set; }
        public DbSet<User> Users { get; set; }
    }
}
