
using Microsoft.AspNetCore.Mvc;
using EcoDriveLocator.Core.Entities;
using EcoDriveLocator.Infrastructure.Repositories;
using System.Threading.Tasks;

namespace EcoDriveLocator.WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ChargingSessionController : ControllerBase
    {
        private readonly IChargingSessionRepository _chargingSessionRepository;

        public ChargingSessionController(IChargingSessionRepository chargingSessionRepository)
        {
            _chargingSessionRepository = chargingSessionRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetChargingSessions()
        {
            var sessions = await _chargingSessionRepository.GetAllChargingSessionsAsync();
            return Ok(sessions);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetChargingSession(int id)
        {
            var session = await _chargingSessionRepository.GetChargingSessionByIdAsync(id);
            if (session == null) return NotFound();
            return Ok(session);
        }

        [HttpPost]
        public async Task<IActionResult> CreateChargingSession([FromBody] ChargingSession session)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            await _chargingSessionRepository.AddChargingSessionAsync(session);
            return CreatedAtAction(nameof(GetChargingSession), new { id = session.Id }, session);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateChargingSession(int id, [FromBody] ChargingSession session)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var existingSession = await _chargingSessionRepository.GetChargingSessionByIdAsync(id);
            if (existingSession == null) return NotFound();
            session.Id = id;
            await _chargingSessionRepository.UpdateChargingSessionAsync(session);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteChargingSession(int id)
        {
            var session = await _chargingSessionRepository.GetChargingSessionByIdAsync(id);
            if (session == null) return NotFound();
            await _chargingSessionRepository.DeleteChargingSessionAsync(id);
            return NoContent();
        }
    }
}
