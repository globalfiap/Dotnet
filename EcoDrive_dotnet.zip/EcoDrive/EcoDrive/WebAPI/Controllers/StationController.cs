
using Microsoft.AspNetCore.Mvc;
using EcoDriveLocator.Core.Entities;
using EcoDriveLocator.Infrastructure.Repositories;
using System.Threading.Tasks;

namespace EcoDriveLocator.WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StationController : ControllerBase
    {
        private readonly IStationRepository _stationRepository;

        public StationController(IStationRepository stationRepository)
        {
            _stationRepository = stationRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetStations()
        {
            var stations = await _stationRepository.GetAllStationsAsync();
            return Ok(stations);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetStation(int id)
        {
            var station = await _stationRepository.GetStationByIdAsync(id);
            if (station == null) return NotFound();
            return Ok(station);
        }

        [HttpPost]
        public async Task<IActionResult> CreateStation([FromBody] Station station)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            await _stationRepository.AddStationAsync(station);
            return CreatedAtAction(nameof(GetStation), new { id = station.Id }, station);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateStation(int id, [FromBody] Station station)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var existingStation = await _stationRepository.GetStationByIdAsync(id);
            if (existingStation == null) return NotFound();
            station.Id = id;
            await _stationRepository.UpdateStationAsync(station);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStation(int id)
        {
            var station = await _stationRepository.GetStationByIdAsync(id);
            if (station == null) return NotFound();
            await _stationRepository.DeleteStationAsync(id);
            return NoContent();
        }
    }
}
