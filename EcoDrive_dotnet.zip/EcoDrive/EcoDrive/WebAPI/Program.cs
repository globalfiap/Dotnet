using Microsoft.EntityFrameworkCore;
using EcoDriveLocator.Infrastructure.Data;
using EcoDriveLocator.Infrastructure.Repositories;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseOracle(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddScoped<IStationRepository, StationRepository>();
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "EcoDrive API",
        Version = "v1",
        Description = "API para localizar e gerenciar estações de carregamento de carros elétricos."
    });
});

var app = builder.Build();

// Configure Swagger for all environments
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "EcoDrive API v1");
    c.RoutePrefix = string.Empty; // Configura Swagger como página principal
});

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
