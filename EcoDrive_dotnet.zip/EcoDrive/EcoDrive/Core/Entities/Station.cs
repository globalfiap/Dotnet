
using System.ComponentModel.DataAnnotations;

namespace EcoDriveLocator.Core.Entities
{
    public class Station
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Address { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public int AvailableSlots { get; set; }
        [Required]
        public string ChargerTypes { get; set; } // Comma-separated values of charger types
        
        public decimal PricePerKWh { get; set; }

        public Station()
        {
            Name = string.Empty;
            Address = string.Empty;
            ChargerTypes = string.Empty;
        }
        
    }
}
